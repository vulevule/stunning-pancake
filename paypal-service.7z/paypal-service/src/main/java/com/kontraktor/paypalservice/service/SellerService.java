package com.kontraktor.paypalservice.service;

import java.io.IOException;
import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kontraktor.paypalservice.repository.SellerRepository;
import com.kontraktor.paypalservice.restClient.PayPalApi;
import com.kontraktor.paypalservice.restClient.PayPalAuthResponse;
import com.kontraktor.paypalservice.seller.AuthToken;
import com.kontraktor.paypalservice.seller.SellerInfo;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
@Service
public class SellerService {
	@Autowired
	private SellerRepository sellerRepo;
	@Autowired
	private PayPalApi payPalApi;
	public void getAccessToken(Long userId){
		SellerInfo seller = sellerRepo.findOne(userId);
		Call<PayPalAuthResponse> call = payPalApi.getAccessToken("client_credentials", "Basic " + seller.getClientCredentialsBase64Encoded());
		
		Response<PayPalAuthResponse> response = null;
		try {
			response = call.execute();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		AuthToken token = new AuthToken();
		token.setToken(response.body().getAccess_token());
		Calendar calendar = Calendar.getInstance(); // gets a calendar using the default time zone and locale.
		calendar.add(Calendar.SECOND, Integer.parseInt(response.body().getExpires_in()) - 120);
		token.setExpireDate(calendar.getTime());
		seller.setToken(token);
		sellerRepo.save(seller);
	}
}
