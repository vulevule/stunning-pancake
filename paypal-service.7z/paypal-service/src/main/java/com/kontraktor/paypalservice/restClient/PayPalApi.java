package com.kontraktor.paypalservice.restClient;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface PayPalApi {
	@FormUrlEncoded
	@Headers({"content-type: application/x-www-form-urlencoded", "cache-control: no-cache"})
	@POST("v1/oauth2/token")
	public Call<PayPalAuthResponse> getAccessToken(@Field("grant_type") String grantType, @Header("authorization") String clientIdclientSecret);
}
