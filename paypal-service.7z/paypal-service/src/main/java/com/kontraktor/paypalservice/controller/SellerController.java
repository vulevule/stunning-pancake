package com.kontraktor.paypalservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kontraktor.paypalservice.repository.AuthTokenRepository;
import com.kontraktor.paypalservice.seller.AuthToken;
import com.kontraktor.paypalservice.seller.SellerInfo;
import com.kontraktor.paypalservice.service.SellerService;

@Controller
@RequestMapping("/api/paypal")
public class SellerController {
	@Autowired
	private SellerService sellerService;
	@Autowired AuthTokenRepository sr;
	@GetMapping("/token")
	public ResponseEntity<AuthToken> getAccessToken(){
		sellerService.getAccessToken(1L);
		System.out.println("prosao");
		return new ResponseEntity<AuthToken>(sr.findOne(1L), HttpStatus.OK);
	}
}
